INSERT INTO clientes 
(pk_nu_cedula,var_nombre,var_apellido,var_direcci,nu_telefo,da_fe_naci)
VALUES
(105440178,'Alex','Garcia','Kr 12a # 51c -98',3146557089,'22/04/1990');

INSERT INTO clientes 
(pk_nu_cedula,var_nombre,var_apellido,var_direcci,nu_telefo,da_fe_naci)
VALUES
(105430168,'Luis','Perez','Kr 112a # 151c -68',3145577089,'22/01/1989');

INSERT INTO clientes 
(pk_nu_cedula,var_nombre,var_apellido,var_direcci,nu_telefo,da_fe_naci)
VALUES
(195470378,'Juana','Alvarez','Calle 112a # 151c - 50',3146557089,'27/12/1993');

describe puntos_clientes

select * from puntos_clientes

INSERT INTo puntos_clientes
VALUES (195470378,1001,1800,20,'01/03/2020');

INSERT INTo puntos_clientes
VALUES (105430168,1002,2000,20,sysdate);


